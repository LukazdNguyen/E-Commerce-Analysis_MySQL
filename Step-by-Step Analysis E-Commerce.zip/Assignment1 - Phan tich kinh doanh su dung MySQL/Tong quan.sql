use mavenfuzzyfactory
-- Yeu cau 1 --
select 
	year(website_sessions.created_at) as yr,
    quarter(website_sessions.created_at) as qtr,
    count(distinct website_sessions.website_session_id) as sessions,
    count(distinct orders.order_id) as orders
from website_sessions
	left join orders
		on orders.website_session_id = website_sessions.website_session_id
group by 1,2

-- Yeu cau 2 --
select 
	year(website_sessions.created_at) as yr,
    quarter(website_sessions.created_at) as qtr,
    count(distinct website_sessions.website_session_id) as sessions,
    count(distinct orders.order_id) as orders,
    count(distinct orders.order_id)/count(distinct website_sessions.website_session_id) as sessions_to_conv_rt_orders,
    sum(orders.price_usd) / count(distinct orders.order_id) as revenue_per_order,
    sum(orders.price_usd) / count(distinct website_sessions.website_session_id) as revenue_per_sessions
from website_sessions
left join orders
	on orders.website_session_id = website_sessions.website_session_id
group by 1,2

-- Yeu cau 3 --
Select 
	year(website_sessions.created_at) as yr,
    quarter(website_sessions.created_at) as qtr,
    count(distinct case when utm_campaign = 'nonbrand' and utm_source = 'gsearch' then orders.order_id else null end) as gsearch_nonbrand_orders,
    count(distinct case when utm_campaign = 'nonbrand' and utm_source = 'bsearch' then orders.order_id else null end) as bsearch_nonbrand_orders,
    count(distinct case when utm_campaign = 'brand' then orders.order_id else null end) as brand_search_orders,
    count(distinct case when utm_source is null and http_referer is not null then orders.order_id else null end) as organic_type_in_orders,
    count(distinct case when utm_source is null and http_referer is null then orders.order_id else null end) as direct_type_in_orders
from website_sessions
left join orders
	on website_sessions.website_session_id = orders.website_session_id
group by 1,2

-- Yeu cau 4 -- 
Select 
	year(website_sessions.created_at) as yr,
    quarter(website_sessions.created_at) as qtr,
    count(distinct case when utm_campaign = 'nonbrand' and utm_source = 'gsearch' then orders.order_id else null end) / 
    count(distinct case when utm_campaign = 'nonbrand' and utm_source = 'gsearch' then website_sessions.website_session_id else null end) as gsearch_nonbrand_conv_rt,
    count(distinct case when utm_campaign = 'nonbrand' and utm_source = 'bsearch' then orders.order_id else null end)
    /count(distinct case when utm_campaign = 'nonbrand' and utm_source = 'bsearch' then website_sessions.website_session_id else null end) as bsearch_nonbrand_conv_rt,
    count(distinct case when utm_campaign = 'brand' then orders.order_id else null end)
    /count(distinct case when utm_campaign = 'brand' then website_sessions.website_session_id else null end) as brand_search_conv_rt,
    count(distinct case when utm_source is null and http_referer is not null then orders.order_id else null end)
    /count(distinct case when utm_source is null and http_referer is not null then website_sessions.website_session_id else null end ) as organic_search_conv_rt,
    count(distinct case when utm_source is null and http_referer is null then orders.order_id else null end)/
    count(distinct case when utm_source is null and http_referer is null then website_sessions.website_session_id else null end) as direct_type_in_conv_rt
from website_sessions
left join orders
	on website_sessions.website_session_id = orders.website_session_id
group by 1,2

-- Yeu cau 5 --
select
	year(created_at) as yr,
    month(created_at) as mo,
	sum(case when product_id = 1 then price_usd else null end) as mrfuzzy_rev,
    sum(case when product_id = 1 then price_usd - cogs_usd else null end) as mrfuzzy_marg,
    sum(case when product_id = 2 then price_usd else null end) as lovebear_rev,
    sum(case when product_id = 2 then price_usd - cogs_usd else null end) as lovebear_marg,
    sum(case when product_id = 3 then price_usd else null end) as birthday_rev,
    sum(case when product_id = 3 then price_usd - cogs_usd else null end) as birthday_marg,
	sum(case when product_id = 4 then price_usd else null end) as minbear_rev,
    sum(case when product_id = 4 then price_usd - cogs_usd else null end) as minbear_marg,
    sum(price_usd) as total_rev,
    sum(price_usd - cogs_usd) as total_marg
from order_items
group by 1,2
order by 1,2
;

-- Yeu cau 6 --
create temporary table product_pageviews
select 
	website_session_id,
    website_pageview_id,
    created_at as saw_product_view_id
from website_pageviews
where pageview_url = '/products';

select
	year(a.saw_product_view_id) as yr,
    month(a.saw_product_view_id) as mo,
    count(distinct a.website_session_id) as sessions_to_product_page,
    count(distinct b.website_session_id) as click_to_next_page,
    count(distinct b.website_session_id)/count(distinct a.website_session_id) as clickthrough_rt,
    count(distinct c.order_id) as orders,
    count(distinct c.order_id) /count(distinct a.website_session_id) as product_to_order_rt
from product_pageviews a
left join website_pageviews b
	on b.website_session_id = a.website_session_id 
    and b.website_pageview_id > a.website_pageview_id-- same session
left join orders c
	on a.website_session_id = c.website_session_id -- they had another page AFTER
group by 1,2

/*
-- Cau 7: We made our 4th product available on December 05, 2014( it was previously only a cross-sell item),
-- could you please pull sales data since then, and show how well each product cross-sells from one another?
*/

create temporary table primary_products
Select 
	order_id,
    primary_product_id,
    created_at as orders_at
from orders
where created_at > '2014-12-05' -- when the 4th product was add(says so in question)
;

Select 
	primary_product_id,
    count(distinct order_id) as total_orders,
    count(distinct case when cross_sell_product_id = 1 then order_id else null end) as _xsold_p1,
    count(distinct case when cross_sell_product_id = 2 then order_id else null end) as _xsold_p2,
    count(distinct case when cross_sell_product_id = 3 then order_id else null end) as _xsold_p3,
    count(distinct case when cross_sell_product_id = 4 then order_id else null end) as _xsold_p4,
    count(distinct case when cross_sell_product_id = 1 then order_id else null end)/
    count(distinct order_id) as p1_xsell_p1,
    count(distinct case when cross_sell_product_id = 2 then order_id else null end)/
    count(distinct order_id) as p1_xsell_p2,
    count(distinct case when cross_sell_product_id = 3 then order_id else null end)/
    count(distinct order_id) as p1_xsell_p3,
    count(distinct case when cross_sell_product_id = 4 then order_id else null end)/
    count(distinct order_id) as p1_xsell_p4
from (
Select
	primary_products.*,
    order_items.product_id as cross_sell_product_id
from primary_products 
left join order_items 
	on order_items.order_id = primary_products.order_id
    and order_items.is_primary_item = 0
) as primary_w_cross_sell
group by 1;

-- Cau 8: 
-- Step 1:
-- Tối ưu hóa Chuyển đổi (Conversion Optimization):
-- Phân tích chi tiết tỷ lệ chuyển đổi từ lượt xem sản phẩm đến việc đặt hàng, từ đó tìm ra các điểm yếu trong quá trình mua hàng và tối ưu hóa trang web để tăng tỷ lệ chuyển đổi.
-- Áp dụng kỹ thuật A/B testing để kiểm tra hiệu suất của các thay đổi trên trang web và xác định các phương pháp tối ưu hóa hiệu quả.

-- Step 2:
-- Nâng cao Trải nghiệm Khách hàng:
-- Tạo ra một trải nghiệm mua sắm trực tuyến tốt hơn thông qua việc cải thiện giao diện người dùng, tăng cường tính năng và dịch vụ hỗ trợ khách hàng.
-- Sử dụng phản hồi từ khách hàng để liên tục cải thiện sản phẩm và dịch vụ.

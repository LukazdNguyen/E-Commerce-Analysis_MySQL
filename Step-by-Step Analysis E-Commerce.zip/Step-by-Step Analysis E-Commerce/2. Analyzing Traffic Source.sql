-- use mavenfuzzyfactory
-- LAB 2: Phân tích lưu lượng Website -- 
-- Requirement 1 - Khảo sát nguồn lưu lượng --
Select 
utm_source,
utm_campaign,
http_referer,
count(distinct website_session_id) as number_session
from website_sessions
where created_at < '2012-04-12'
group by 1,2,3 
order by number_session desc;

-- Requirement 2 - Tỷ lệ chuyển đổi từ nguồn lưu lượng truy cập --
-- Yeu to quan trong dat ra o day la:
-- Yêu cầu đặt ra là tỷ lệ CVR phải lớn hơn 4%. Nếu bạn tính ra CVR thấp hơn 4% thì có nghĩa bạn phải giảm bid. 
-- Nếu bạn tính ra CVR cao hơn thì có nghĩa bạn có thể tăng bid.

Select 
count(distinct A.website_session_id) as sessions,
count(distinct B.order_id) as orders,
count(distinct B.order_id) / count(distinct A.website_session_id) as session_to_order_conv_rt
from website_sessions A
left join orders B
	on A.website_session_id = B.website_session_id
where A.created_at < '2012-04-12'
	and utm_source = 'gsearch'
    and utm_campaign = 'nonbrand';

-- Requirement 3: Xu hướng nguồn lưu lượng truy cập -- 
Select 
min(date(created_at)) as week_started_at,
count(distinct website_session_id) as sessions
from website_sessions
where created_at < '2012-05-15'
	and created_at > '2012-04-15'
	and utm_source = 'gsearch'
    and utm_campaign = 'nonbrand'
group by 
	year(created_at),
    week(created_at);

-- Requirement 4: Tối ưu hoá bid cho các lưu lượng có trả tiền --
-- Nếu CVR trên Desktop tốt hơn trên mobile thì có thể tăng bid trên các session truy cập bằng Desktop.--
Select 
website_sessions.device_type,
-- count(distinct website_sessions.website_session_id) sessions,
count(distinct orders.order_id) as orders,
count(distinct orders.order_id) / count(distinct website_sessions.website_session_id) as conv_rt
from website_sessions
left join orders
	on website_sessions.website_session_id = orders.website_session_id
where website_sessions.created_at < '2012-05-11'
	and website_sessions.utm_source = 'gsearch'
    and website_sessions.utm_campaign = 'nonbrand'
group by website_sessions.device_type;

-- Requirement 5: Kiểm tra kết quả khi tăng bid --
Select 
	min(date(created_at)) as week_started_at,
	count(distinct case when device_type = 'desktop' then website_session_id  else null end) as desktop_sessions,
	count(distinct case when device_type = 'mobile' then website_session_id  else null end) as mobile_sessions
from website_sessions
where created_at < '2012-05-19'
	and created_at  > '2012-04-15'
	and utm_source = 'gsearch'
	and utm_campaign = 'nonbrand'
group by 
	year(created_at),
	week(created_at);


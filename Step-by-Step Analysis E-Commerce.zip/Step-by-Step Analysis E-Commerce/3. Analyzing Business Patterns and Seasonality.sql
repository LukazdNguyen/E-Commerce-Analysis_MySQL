use mavenfuzzyfactory
-- Analyzing Seasonality
Select 
year(A.created_at) as yr,
month(A.created_at) as mo,
count(distinct A.website_session_id) as sessions,
count(distinct B.order_id) as orders
from website_sessions A
left join orders B
	on A.website_session_id = B.website_session_id
where A.created_at < '2013-01-01'
group by 
	year(A.created_at),
	month(A.created_at)
-- We will do it compare detail on the better while we changing Month to Week (website_sessions.created_at)
-- On the between 2012-11-18 (47 wks) and 2012-11-25 (48 wks) we can see order, session quantities have growth in abnormally.
-- So, on my opnion for in case. This timeline can be a BlackFriday or something stuff.
Select 
min(date(A.created_at)) as week_started_at,
week(A.created_at) as wk,
count(distinct A.website_session_id) as sessions,
count(distinct B.order_id) as orders
from website_sessions A
left join orders B
	on A.website_session_id = B.website_session_id
where A.created_at < '2013-01-01'
group by 
	year(A.created_at),
	week(A.created_at)
-- Analyzing Business Patterns 
Select 
	hr,
	AVG(website_sessions) as avg_sessions,
    round(avg(case when wkday = 0 then website_sessions else null end),1) as mon,
    round(avg(case when wkday = 1 then website_sessions else null end),1) as tues,
    round(avg(case when wkday = 2 then website_sessions else null end),1) as weds,
	round(avg(case when wkday = 3 then website_sessions else null end),1) as thurs,
    round(avg(case when wkday = 4 then website_sessions else null end),1) as fri,
    round(avg(case when wkday = 5 then website_sessions else null end),1) as sat,
    round(avg(case when wkday = 6 then website_sessions else null end),1) as sun
from(
select 
	date(created_at) as created_date,
	weekday(created_at) as wkday,
	hour(created_at) as hr,
	count(distinct website_session_id) as website_sessions
from website_sessions 
where created_at between '2012-09-15' and '2012-11-15'
group by 1,2,3
) as daily_hourly_sessions
group by 1
-- use mavenfuzzyfactory
-- LAB 2: Phân tích hiệu suất Website -- 
-- Requirement 1 - Tìm các trang web có lượt xem nhiều nhất --
Select 
	pageview_url,
	count(distinct website_pageview_id) as pvs
from website_pageviews
where created_at < '2012-06-09'
group by 1
order by pvs desc;

-- Requirement 2 - Tìm tổng số lượng session truy cập mỗi trang web vào lần đầu tiên
create temporary table first_pv_per_session
Select 
website_session_id,
min(website_pageview_id) as first_pv
from website_pageviews
where created_at < '2012-06-12'
group by 1;

Select 
B.pageview_url as landing_page_url,
count(distinct A.website_session_id) as session_hitting_page
from first_pv_per_session A
left join website_pageviews B
	on A.website_session_id = B.website_session_id
group by 1
order by session_hitting_page desc;

-- Requirement 3: Phân tích landing page --

create temporary table first_pageviews
Select 
	website_session_id,
	min(website_pageview_id) as pvs
from website_pageviews
where created_at < '2012-06-14'
group by 1;

create temporary table session_w_home_landing_page
select 
A.website_session_id,
B.pageview_url
from first_pageviews A
left join website_pageviews B
	on A.website_session_id = B.website_session_id
where B.pageview_url = '/home';

-- Bảng bounced_sessions để tìm ra các session chỉ chứa 1 một trang web là /home,
-- nếu session chỉ truy cập duy nhất 1 trang là /home thì cũng đồng nghĩa session này đã xảy
-- ra tình trạng thoát phiên

create temporary table bounced_sessions
Select 
	A.website_session_id,
	A.pageview_url,
	count(distinct B.website_pageview_id) as count_of_pages_viewed
from session_w_home_landing_page A
left join website_pageviews B
	on A.website_session_id = B.website_session_id
group by 
	A.website_session_id,
    A.pageview_url
having count(B.website_pageview_id) = 1;

-- Truy vấn này để tìm ra những phiên có trong bảng
-- session_w_home_landing_page nhưng không có trong bảng bounced_sessions, những
-- phiên có trong bảng bounced_sessions chính là những phiên xảy ra tình trạng thoát phiên

Select 
	count(distinct A.website_session_id) as sessions,
    count(distinct B.website_session_id) as bounced_sessions,
    count(distinct B.website_session_id) / count(distinct A.website_session_id) as bounced_rate
from session_w_home_landing_page A
left join bounced_sessions B
	on A.website_session_id = B.website_session_id

-- Requirement 4: A/B testing --
-- Step 1: find out the new page /lander lanched: --

Select
	min(created_at) as first_started_at,
	min(website_pageview_id) as first_pageview_id
from website_pageviews
where pageview_url = '/lander-1' and created_at is not null;

-- => first_started_at = '2012-06-19 00:35:54' --
-- => first_pageview_id = '23504'

-- Step 2: finding the first website_pageview_id for relevant sessions -- 
create temporary table first_test_pageviews
Select
	A.website_session_id,
    min(A.website_pageview_id) as min_pageview_id
from website_pageviews A
inner join website_sessions B
	on A.website_session_id = B.website_session_id
	and B.created_at < '2012-07-28' -- prescribed by the assignment --
	and A.website_pageview_id > 23504 -- the min_pageview_id we found for the test
    and utm_source = 'gsearch'
    and utm_campaign = 'nonbrand'
group by 
	A.website_session_id;
    
-- Step 3: Mapping web_pageview_id and landing page (/home, /lander-1)

create temporary table session_w_home_lander1_landing_page
Select
	A.website_session_id,
	B.pageview_url as landing_page
from first_test_pageviews A
left join website_pageviews B
	on A.website_session_id = B.website_session_id
where B.pageview_url in ('/home' , '/lander-1');

-- Step 4: Counting pageviews for each sessions, to identify "bounces" --
create temporary table bounced_session
Select 
	A.website_session_id,
    A.landing_page,
    count(distinct B.website_pageview_id) as count_pageview_id
from session_w_home_lander1_landing_page A
Left join website_pageviews B
	on A.website_session_id = B.website_session_id
group by 
	A.website_session_id,
    A.landing_page
having 
	count(B.website_pageview_id) = 1;
    
-- Step 5: Summarizing total sessions and bounced sessions (/home; /lander-1)

Select 
	A.landing_page,
    count(distinct A.website_session_id) as sessions,
    count(distinct B.website_session_id) as bounced_session,
    count(distinct B.website_session_id) / count(distinct A.website_session_id) as bounced_rate
from session_w_home_lander1_landing_page A
Left join bounced_session B
	on A.website_session_id = B.website_session_id
group by A.landing_page




use mavenfuzzyfactory
-- LAB 4: Product Analysis --
-- Requirement 1: Product-Level Sales Analysis --
Select
year(created_at) as yr,
month(created_at) as mo,
count(distinct order_id) as number_of_states,
sum(price_usd) as total_revenue,
sum(price_usd - cogs_usd) as total_margin
from orders
where created_at < '2013-04-01'
group by 1,2

-- Requirement 2: Product Launches Analysis--
Select
	year(A.created_at) as yr,
    month(A.created_at) as mo,
    count(distinct A.website_session_id) as sessions,
    count(distinct B.order_id) as orders,
    count(distinct B.order_id) / count(distinct A.website_session_id) as conv_rt,
	sum(price_usd)/count(distinct A.website_session_id ) as revenue_per_session
from website_sessions A
Left join orders B
	on A.website_session_id = B.website_session_id
where A.created_at > '2012-04-01'
	and A.created_at < '2013-04-01'
group by 1,2

-- Requirement 3: Analyzing Product-Level Website Pathing --
-- Step 1: In the website_pageviews table, retrieve all web_sessions in the range from
-- October 6, 2012 to April 6, 2013 with pageview_url = /products. If sessions are created in advance
-- January 6, 2013 will be assigned as 'A. Pre_Product_2', otherwise it will be assigned as B.Post_Product_2-;.
-- finding the /products pageviews we care about
create temporary table Products_pageviews
Select 
	website_session_id, 
	website_pageview_id,
	created_at,
	case 
		when created_at < '2013-01-06' then 'A.Pre_Product_2' 
        when created_at > '2013-01-06' then 'B.Post_Product_2'
        else 'something...' end as time_period
from website_pageviews
where created_at > '2012-10-06'
	and created_at < '2013-04-06'
	and pageview_url = '/products'
group by 1,2,3;

-- Step 2: Write a query that retrieves the website_pageview_id immediately after the user visits
-- into /products (use the results of step 1 combined with the website_pageviews table). Conclude
-- the output looks like this:
-- find the next pageview id that occurs AFTER the product pageview
create temporary table session_w_next_pageview_id
select 
A.time_period,
A.website_session_id,
min(B.website_pageview_id) as min_next_pageview_id
from Products_pageviews A
left join website_pageviews B
	on A.website_session_id = B.website_session_id
	and B.website_pageview_id > A.website_pageview_id
group by 1,2;

-- Step 3: find the pageview_url associated with any applicable next pageview id --
create temporary table session_w_next_pageview_url
select 
	A.time_period,
	A.website_session_id,
	B.pageview_url as next_pageview_url
from session_w_next_pageview_id A
left join website_pageviews B
	on A. min_next_pageview_id = B.website_pageview_id;

-- Step 4:
select 
time_period,
count(distinct website_session_id) as sessions,
count(distinct case when next_pageview_url is not null then website_session_id else null end) as w_next_pg,
count(distinct case when next_pageview_url is not null then website_session_id else null end)/
count(distinct website_session_id) as pct_w_next_pg,
count(distinct case when next_pageview_url = '/the-original-mrfuzzy' is not null then website_session_id else null end) as to_mrfuzzy,
count(distinct case when next_pageview_url = '/the-original-mrfuzzy' is not null then website_session_id else null end) /
count(distinct website_session_id) as pct_to_mrfuzzy,
count(distinct case when next_pageview_url = '/the-forever-love-bear' is not null then website_session_id else null end) as to_lovebear,
count(distinct case when next_pageview_url = '/the-forever-love-bear' is not null then website_session_id else null end)/
count(distinct website_session_id) as pct_to_lovebear
from session_w_next_pageview_url
group by 1

-- Requirement 4: Analyzing to build Product-Level Conversion Funnels--
-- Step 1: Select all pageviews for relevant sessions --

create temporary table sessions_seeing_product_pages
Select 
	website_session_id,
    website_pageview_id,
    pageview_url as product_page_seen
from website_pageviews
where created_at < '2013-04-10'
	and created_at > '2013-01-06'
    and pageview_url in ('/the-original-mr-fuzzy', '/the-forever-love-bear');
    
-- Step 2: finding the right pageview_urls to build funnels --

Select distinct
	b.pageview_url 
from sessions_seeing_product_pages a
left join website_pageviews b
	on a.website_session_id = b.website_session_id
    and a.website_pageview_id < b.website_pageview_id
    
-- Step 3:
-- we'll look at the inner query first to look over the pageview_level results
-- then, turn it into a subquery and make it summary with flags
Select 
	a.website_session_id,
    a.product_page_seen,
    case when pageview_url = '/cart' then 1 else 0 end as cart_page,
    case when pageview_url = '/shipping' then 1 else 0 end as shipping_page,
    case when pageview_url = '/billing-2' then 1 else 0 end as bill_page,
    case when pageview_url = '/thank-you-for-your-order' then 1 else 0 end as thankyou_page
from sessions_seeing_product_pages a
left join website_pageviews b
	on a.website_session_id = b.website_session_id
    and a.website_pageview_id < b.website_pageview_id
order by 
	a.website_session_id,
    a.product_page_seen

-- Step 4: Drop the all Step 3 pull 
create temporary table session_product_level_made_it_flags
Select 
	website_session_id,
    case 
		when product_page_seen = '/the-original-mr-fuzzy' then 'mrfuzzy'
        when product_page_seen = '/the-forever-love-bear' then 'lovebear'
        else 'something other stuff'
	end as product_seen,
	max(cart_page) as cart_made_it,
    max(shipping_page) as shipping_made_it,
    max(bill_page) as bill_made_it,
    max(thankyou_page) as thankyou_made_it
from(
Select 
	a.website_session_id,
    a.product_page_seen,
    case when pageview_url = '/cart' then 1 else 0 end as cart_page,
    case when pageview_url = '/shipping' then 1 else 0 end as shipping_page,
    case when pageview_url = '/billing-2' then 1 else 0 end as bill_page,
    case when pageview_url = '/thank-you-for-your-order' then 1 else 0 end as thankyou_page
from sessions_seeing_product_pages a
left join website_pageviews b
	on a.website_session_id = b.website_session_id
    and a.website_pageview_id < b.website_pageview_id
order by 
	a.website_session_id,
    a.product_page_seen
) as pageview_level
group by 
	website_session_id,
    case 
		when product_page_seen = '/the-original-mr-fuzzy' then 'mrfuzzy'
        when product_page_seen = '/the-forever-love-bear' then 'lovebear'
	else 'something other stuff'
	end
;

-- Final output part 1: --
Select 
	product_seen,
    count(distinct website_session_id) as sessions,
    count(distinct case when cart_made_it = 1 then website_session_id else null end) as to_cart,
    count(distinct case when shipping_made_it = 1 then website_session_id else null end) as to_shipping,
    count(distinct case when bill_made_it = 1 then website_session_id else null end) as to_bill,
    count(distinct case when thankyou_made_it = 1 then website_session_id else null end) as to_thankyou
from session_product_level_made_it_flags
group by product_seen

-- then this as final output part 2 - click rates
Select 
	product_seen,
    count(distinct case when cart_made_it = 1 then website_session_id else null end) /  count(distinct website_session_id) as product_page_click_rt,
    count(distinct case when shipping_made_it = 1 then website_session_id else null end) 
    / count(distinct case when cart_made_it = 1 then website_session_id else null end) as cart_click_rt,
    count(distinct case when bill_made_it = 1 then website_session_id else null end) 
    / count(distinct case when shipping_made_it = 1 then website_session_id else null end) as shipping_click_rt,
    count(distinct case when thankyou_made_it = 1 then website_session_id else null end) 
    / count(distinct case when bill_made_it = 1 then website_session_id else null end)  as bill_click_rt
from session_product_level_made_it_flags
group by product_seen

-- Requirement 5: Cross-Sell Analysis
-- Step 1: Identify the relevant /cart pageviews and their sessions
-- Step 2: See which of those /cart sessions clicked through to the shipping page
-- Step 3: Find the orders associated with the /cart sessions. Analyze products purchased, ADV
-- Step 4: Aggregate and analyze a summary of our findings
create temporary table sessions_seeing_cart
Select
	Case
		when created_at < '2013-09-25' then 'A.Pre_Cost_Sell'
        when created_at > '2013-01-06' then 'B.Post_Cost_Sell'
        else 'Something Stuff...bla bla'
	end as time_period,
	website_session_id as cart_session_id,
    website_pageview_id as cart_pageview_id
from website_pageviews
where created_at between '2013-08-25' and '2013-10-25'
	and pageview_url = '/cart';

create temporary table cart_sessions_seeing_another_page
select 
	a.time_period,
    a.cart_session_id,
    min(b.website_pageview_id) as pv_id_after_cart
from sessions_seeing_cart a
left join website_pageviews b
	on a.cart_session_id = b.website_session_id
    and a.cart_pageview_id < b.website_pageview_id
group by
	a.time_period,
    a.cart_session_id
having min(b.website_pageview_id) is not null;

create temporary table pre_post_session_orders
select 
	a.time_period,
    a.cart_session_id,
    b.order_id,
    b.items_purchased,
    b.price_usd
from sessions_seeing_cart a
inner join orders b
	on a.cart_session_id = b.website_session_id;

-- first, we'll look at this select statement --
-- then we'll turn it into a subquery --

Select
	time_period,
    count(distinct cart_session_id) as cart_sessions,
	sum(click_to_another_page) as click_through,
    sum(click_to_another_page) / count(distinct cart_session_id) as cart_click_through,
    sum(placed_orders) as orders_placed,
    sum(items_purchased) as product_purchased,
    sum(items_purchased) / sum(placed_orders) as product_per_orders,
    sum(price_usd) as total_revenue,
    sum(price_usd) /  sum(placed_orders) as aov,
    sum(price_usd) / count(distinct cart_session_id) as rev_per_cart_session
from (
Select 
	a.time_period,
    a.cart_session_id,
    case when b.cart_session_id is null then 0 else 1 end as click_to_another_page,
    case when c.order_id is null then 0 else 1 end as placed_orders,
    c.items_purchased,
    c.price_usd
from sessions_seeing_cart a
left join cart_sessions_seeing_another_page b
    on a.cart_session_id = b.cart_session_id 
left join pre_post_session_orders c
	on a.cart_session_id = c.cart_session_id
order by 
	cart_session_id
) as full_data
group by
	time_period;

-- Requirement 6: Product Porfolio Expansion
Select
	case
		when a.created_at < '2013-12-12' then 'A.Pre_Birthday_Bear'
        when a.created_at >= '2013-12-12' then 'B.Post_Birthday_Bear'
	else 'Nothing...'
    end as time_period,
	count(distinct a.website_session_id) as sessions,
    count(distinct b.order_id) as orders,
    count(distinct b.order_id) / count(distinct a.website_session_id) as conv_rate,
    sum(b.price_usd) as total_revenue,
    sum(b.items_purchased) as total_product_sold,
	sum(b.price_usd) / count(distinct b.order_id) as avg_order_value,
    sum(b.items_purchased) /  count(distinct b.order_id) as product_per_orders,
    sum(b.items_purchased) / count(distinct a.website_session_id) as revenue_per_sessions
from website_sessions a
left join orders b
	on a.website_session_id = b.website_session_id
where a.created_at between '2013-11-12' and '2014-01-12'
group by 
	time_period;
    
-- Final Requirement: Analyzing Product-Refund Rates--
Select
	year(a.created_at) as yr,
    month(a.created_at) as mo,
    count(distinct case when product_id = 1 then a.order_item_id else null end) as p1_orders,
    count(distinct case when product_id = 1 then b.order_item_refund_id else null end) /
    count(distinct case when product_id = 1 then a.order_item_id else null end) as p1_refund_rt,
    count(distinct case when product_id = 2 then a.order_item_id else null end) as p2_orders,
    count(distinct case when product_id = 2 then b.order_item_refund_id else null end) /
    count(distinct case when product_id = 2 then a.order_item_id else null end) as p2_refund_rt,
    count(distinct case when product_id = 3 then a.order_item_id else null end) as p3_orders,
    count(distinct case when product_id = 3 then b.order_item_refund_id else null end) /
    count(distinct case when product_id = 3 then a.order_item_id else null end) as p3_refund_rt,
    count(distinct case when product_id = 4 then a.order_item_id else null end) as p4_orders,
    count(distinct case when product_id = 4 then b.order_item_refund_id else null end) /
    count(distinct case when product_id = 4 then a.order_item_id else null end) as p4_refund_rt
from order_items a
left join order_item_refunds b
	on a.order_item_id = b.order_item_id
where a.created_at < '2014-10-15'
group by 1,2

-- ** Analysis for Channel Porfolio Management ** --
-- Requirement 1: Analyzing Channel Porfolios --
select 
yearweek(created_at) as yrwk,
min(date(created_at)) as week_started_at,
count(distinct website_session_id) as total_sessions,
count(distinct case when utm_source = 'gsearch' then website_session_id else null end) as gsearch_sessions,
count(distinct case when utm_source = 'bsearch' then website_session_id else null end) as bsearch_sessions
from website_sessions
where created_at < '2012-11-29'
	and created_at > '2012-08-22'
    and utm_campaign = 'nonbrand'
group by 
	yearweek(created_at);

-- Requirement 2: Comparing Channel Characteristics --
select 
	utm_source,
    count(distinct website_session_id) as sessions,
    count(distinct case when device_type = 'mobile' then website_session_id else null end) as mobile_sessions,
    count(distinct case when device_type = 'mobile' then website_session_id else null end) /
    count(distinct website_session_id) as pct_mobile
from website_sessions
where created_at > '2012-08-22'
	and created_at < '2012-11-30'
    and utm_campaign = 'nonbrand'
group by 1;

-- Requiremnet 3: Cross-Channel Bid Optimization --
Select
	device_type,
	utm_source,
    count(distinct A.website_session_id) as sessions,
    count(distinct B.order_id) as orders,
    count(distinct B.order_id) /  count(distinct A.website_session_id) as conv_rt
from website_sessions A
left join orders B
	on A.website_session_id = B.website_session_id
where A.created_at < '2012-09-19'
	and A.created_at > '2012-08-22'
    and A.utm_campaign = 'nonbrand'
group by 1,2

-- Requirement 4: Analyzing Channel Porfolio Trends --
Select 
min(date(created_at)) as week_started_at,
count(distinct case when utm_source = 'gsearch' and device_type = 'desktop' then website_session_id else null end) as g_dtop_session,
count(distinct case when utm_source = 'bsearch' and device_type = 'desktop' then website_session_id else null end) as b_dtop_session,
count(distinct case when utm_source = 'bsearch' and device_type = 'desktop' then website_session_id else null end)/
count(distinct case when utm_source = 'gsearch' and device_type = 'desktop' then website_session_id else null end) as b_pct_of_g_dtop,
count(distinct case when utm_source = 'gsearch' and device_type = 'mobile' then website_session_id else null end) as g_mob_session,
count(distinct case when utm_source = 'bsearch' and device_type = 'mobile' then website_session_id else null end) as g_mob_session,
count(distinct case when utm_source = 'bsearch' and device_type = 'mobile' then website_session_id else null end)/
count(distinct case when utm_source = 'gsearch' and device_type = 'mobile' then website_session_id else null end) as b_pct_of_g_mob
from website_sessions
where created_at > '2012-11-04'
	and created_at < '2012-12-22'
    and utm_campaign = 'nonbrand'
group by 
	yearweek(created_at)
    
-- Requirement 5: Analyzing Direct Traffic --
Select 
year(created_at) as yr,
month(created_at) as mo,
count(distinct case when channel_group = 'paid_nonbrand'then website_session_id else null end) as nonbrand,
count(distinct case when channel_group = 'paid_brand'then website_session_id else null end) as brand,
count(distinct case when channel_group = 'paid_brand'then website_session_id else null end)
/ count(distinct case when channel_group = 'paid_nonbrand'then website_session_id else null end) as brand_pct_of_nonbrand,
count(distinct case when channel_group = 'direct_type_in' then website_session_id else null end) as direct,
count(distinct case when channel_group = 'direct_type_in' then website_session_id else null end)
/ count(distinct case when channel_group = 'paid_nonbrand'then website_session_id else null end) as direct_pct_of_nonbrand,
count(distinct case when channel_group = 'organic_search' then website_session_id else null end) as organic,
count(distinct case when channel_group = 'organic_search' then website_session_id else null end)
/ count(distinct case when channel_group = 'paid_nonbrand'then website_session_id else null end) as organic_pct_of_nonbrand
from(
Select 
website_session_id,
created_at,
case 
	when utm_source is null and http_referer in ('https://www.gsearch.com', 'http://www.bsearch.com') then 'organic_search'
    when utm_campaign = 'nonbrand' then 'paid_nonbrand' 
    when utm_campaign = 'brand' then 'paid_brand'
    when utm_source is null and http_referer is null then 'direct_type_in'
end as channel_group
from website_sessions
where created_at < '2012-12-23'
) as sessions_w_channel_group
group by 1,2

